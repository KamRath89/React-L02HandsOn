import React from "react";
import ReactDOM from "react-dom";

const stateInfo = (
  state1,
  population1,
  capital1,
  state2,
  population2,
  capital2,
  state3,
  population3,
  capital3,
  state4,
  population4,
  capital4
) => {
  return (
    <table>
      <thead>
        <th>State</th>
        <th>Population</th>
        <th>Capital</th>
      </thead>
      <tbody>
        <tr>
          <td>{state1}</td>
          <td>{population1}</td>
          <td>{capital1}</td>
        </tr>
        <tr>
          <td>{state2}</td>
          <td>{population2}</td>
          <td>{capital2}</td>
        </tr>

        <tr>
          <td>{state3}</td>
          <td>{population3}</td>
          <td>{capital3}</td>
        </tr>
        <tr>
          <td>{state4}</td>
          <td>{population4}</td>
          <td>{capital4}</td>
        </tr>
      </tbody>
    </table>
  );
};

ReactDOM.render(
  stateInfo(
    "Idaho",
    "1.981 Million", //The example didn't have a number here so I just put one in.
    "Boise",
    "Tennessee",
    "6.651 Million",
    "Nashville",
    "Maine",
    "1.331 Million",
    "Austa",
    "Wisconsin",
    "5.779 Million",
    "Madison"
  ),
  document.getElementById("root")
);
